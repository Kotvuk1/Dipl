const { Router } = require('express');

let r = Router();

let _cache = { data: null, ts: 0 };

r.get('/', async (req, res) => {
  let coin = req.query.coin || '';
  let cacheKey = coin || '_all';
  let now = Date.now();

  if (_cache[cacheKey] && now - _cache[cacheKey].ts < 120000) {
    return res.json(_cache[cacheKey].data);
  }

  try {
    let url = 'https://cryptopanic.com/api/free/v1/posts/?auth_token=pub_free&kind=news&public=true';
    if (coin) url += `&currencies=${coin.toUpperCase()}`;
    let resp = await fetch(url, { signal: AbortSignal.timeout(8000) });
    let body = await resp.json();
    let items = (body.results || []).slice(0, 20).map(p => ({
      title: p.title,
      url: p.url,
      source: p.source ? p.source.title : '',
      published: p.published_at,
      currencies: (p.currencies || []).map(c => c.code),
    }));
    _cache[cacheKey] = { data: items, ts: now };
    res.json(items);
  } catch (ex) {
    res.status(500).json({ err: 'news_unavailable' });
  }
});

module.exports = r;
