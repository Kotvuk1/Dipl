import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useSession } from '../store/session'
import { leave } from '../firebase'

let links = [
  { path: '/app', label: 'Панель', ico: '◈' },
  { path: '/app/analyze', label: 'Анализ', ico: '⟐' },
  { path: '/app/chart', label: 'Графики', ico: '⌇' },
  { path: '/app/trades', label: 'Сделки', ico: '⇄' },
  { path: '/app/signals', label: 'Сигналы', ico: '◎' },
  { path: '/app/analytics', label: 'Статистика', ico: '▣' },
  { path: '/app/news', label: 'Новости', ico: '⊞' },
  { path: '/app/alerts', label: 'Оповещения', ico: '⚡' },
  { path: '/app/learn', label: 'Обучение', ico: '◇' },
  { path: '/app/config', label: 'Настройки', ico: '⚙' },
]

function Sidebar({ collapsed, toggle }) {
  let nav = useNavigate()
  let loc = useLocation()
  let { flame } = useSession()

  let base = {
    width: collapsed ? 64 : 220,
    minHeight: '100vh',
    background: 'rgba(10,10,15,0.95)',
    borderRight: '1px solid rgba(124,58,237,0.15)',
    display: 'flex',
    flexDirection: 'column',
    transition: 'width 0.2s',
    padding: '12px 0',
    overflow: 'hidden',
  }

  let logoStyle = {
    padding: '8px 16px 20px',
    fontFamily: 'JetBrains Mono, monospace',
    fontSize: collapsed ? 16 : 20,
    fontWeight: 700,
    background: 'linear-gradient(135deg, #7c3aed, #06b6d4)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    cursor: 'pointer',
    textAlign: collapsed ? 'center' : 'left',
    whiteSpace: 'nowrap',
  }

  return (
    <div style={base}>
      <div style={logoStyle} onClick={toggle}>
        {collapsed ? 'K' : 'KotvukAI'}
      </div>
      <div style={{ flex: 1 }}>
        {links.map(lk => {
          let active = loc.pathname === lk.path
          return (
            <div
              key={lk.path}
              onClick={() => nav(lk.path)}
              style={{
                padding: collapsed ? '10px 0' : '10px 16px',
                margin: '2px 8px',
                borderRadius: 8,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                background: active ? 'rgba(124,58,237,0.15)' : 'transparent',
                color: active ? '#7c3aed' : '#a0a0b0',
                fontFamily: 'Inter, sans-serif',
                fontSize: 14,
                justifyContent: collapsed ? 'center' : 'flex-start',
                transition: 'all 0.15s',
                whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => { if (!active) e.target.style.background = 'rgba(255,255,255,0.04)' }}
              onMouseLeave={e => { if (!active) e.target.style.background = 'transparent' }}
            >
              <span style={{ fontSize: 18 }}>{lk.ico}</span>
              {!collapsed && lk.label}
            </div>
          )
        })}
      </div>
      {flame && (
        <div style={{ padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          {!collapsed && (
            <div style={{ fontSize: 12, color: '#666', marginBottom: 8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {flame.email}
            </div>
          )}
          <div
            onClick={() => leave()}
            style={{
              padding: '6px 12px', borderRadius: 6, cursor: 'pointer',
              background: 'rgba(239,68,68,0.1)', color: '#ef4444',
              fontSize: 13, textAlign: 'center', fontFamily: 'Inter, sans-serif',
            }}
          >
            {collapsed ? '⏻' : 'Выйти'}
          </div>
        </div>
      )}
    </div>
  )
}

export default Sidebar
