import React, { useState } from 'react'
import { bearerToken } from '../firebase'
import { useToast } from './Toast'

function TradeForm({ signal, onClose, onDone }) {
  let toast = useToast()
  let [vol, setVol] = useState('')
  let [tp, setTp] = useState('')
  let [sl, setSl] = useState('')
  let [lev, setLev] = useState('1')
  let [sending, setSending] = useState(false)

  let sym = signal ? signal.symbol : ''
  let direction = signal ? signal.action : 'LONG'

  async function fire() {
    if (!vol) { toast('Укажи объём', 'err'); return }
    setSending(true)
    try {
      let tkn = await bearerToken()
      let resp = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tkn}` },
        body: JSON.stringify({
          signal_id: signal ? signal.id : null,
          symbol: sym,
          type: direction,
          entry_price: signal ? null : null,
          amount: +vol,
          leverage: +lev,
          take_profit: tp ? +tp : null,
          stop_loss: sl ? +sl : null,
          source: signal ? 'SIGNAL' : 'MANUAL',
        }),
      })
      let data = await resp.json()
      if (data.err) throw new Error(data.err)
      toast('Сделка записана', 'ok')
      if (onDone) onDone(data)
      if (onClose) onClose()
    } catch (e) {
      toast(e.message, 'err')
    }
    setSending(false)
  }

  let overlay = {
    position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999,
  }

  let card = {
    background: '#111118', borderRadius: 16, padding: 28, width: 380,
    border: '1px solid rgba(124,58,237,0.2)',
  }

  let inputStyle = {
    width: '100%', padding: '10px 14px', borderRadius: 8,
    background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
    color: '#e0e0e0', fontFamily: 'Inter, sans-serif', fontSize: 14,
    outline: 'none', marginBottom: 12,
  }

  return (
    <div style={overlay} onClick={onClose}>
      <div style={card} onClick={e => e.stopPropagation()}>
        <div style={{ fontFamily: 'JetBrains Mono', fontSize: 18, color: '#fff', marginBottom: 20 }}>
          {sym} — {direction}
        </div>
        <input style={inputStyle} placeholder="Объём (USDT)" value={vol} onChange={e => setVol(e.target.value)} type="number" />
        <input style={inputStyle} placeholder="Take Profit" value={tp} onChange={e => setTp(e.target.value)} type="number" />
        <input style={inputStyle} placeholder="Stop Loss" value={sl} onChange={e => setSl(e.target.value)} type="number" />
        <input style={inputStyle} placeholder="Плечо" value={lev} onChange={e => setLev(e.target.value)} type="number" />
        <button
          onClick={fire}
          disabled={sending}
          style={{
            width: '100%', padding: '12px', borderRadius: 8, border: 'none',
            background: direction === 'LONG' ? '#22c55e' : direction === 'SHORT' ? '#ef4444' : 'linear-gradient(135deg, #7c3aed, #06b6d4)',
            color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Inter, sans-serif', opacity: sending ? 0.6 : 1,
          }}
        >
          {sending ? 'Записываю...' : 'Зафиксировать сделку'}
        </button>
      </div>
    </div>
  )
}

export default TradeForm
