import { useState, useEffect, useRef } from 'react'

function useMarket(sym, interval, lim) {
  let [candles, setCandles] = useState([])
  let [tick, setTick] = useState(null)
  let timer = useRef(null)

  useEffect(() => {
    let alive = true

    async function grab() {
      try {
        let resp = await fetch(`/api/market/klines?symbol=${sym}&interval=${interval || '1h'}&limit=${lim || 100}`)
        let data = await resp.json()
        if (alive && Array.isArray(data)) setCandles(data)
      } catch (e) {}
    }

    async function grabTick() {
      try {
        let resp = await fetch(`/api/market/ticker?symbol=${sym}`)
        let data = await resp.json()
        if (alive) setTick(data)
      } catch (e) {}
    }

    grab()
    grabTick()
    timer.current = setInterval(() => { grab(); grabTick() }, 15000)

    return () => { alive = false; clearInterval(timer.current) }
  }, [sym, interval, lim])

  return { candles, tick }
}

export { useMarket }
